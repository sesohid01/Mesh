# MeshTalk - Build Instructions

## Prerequisites

1. **Android Studio** (Hedgehog 2023.1.1 or newer)
   - Download from: https://developer.android.com/studio
2. **Java 17** (included with Android Studio)
3. **Android SDK** (API 26+, API 34 recommended)

---

## How to Build

### Option A: Android Studio (Recommended)

1. Open Android Studio
2. Click **"Open"** and navigate to this project folder
3. Wait for Gradle sync to complete (~2-5 minutes first time)
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. The APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

### Option B: Command Line

```bash
# Make gradlew executable (Linux/Mac)
chmod +x gradlew

# Build debug APK
./gradlew assembleDebug

# Output: app/build/outputs/apk/debug/app-debug.apk
```

On Windows use: `gradlew.bat assembleDebug`

---

## Install on Android Device

### Via ADB (USB debugging enabled):
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Manual install:
1. Transfer the APK to your Android device
2. Enable "Install from unknown sources" in Settings
3. Tap the APK file to install

---

## Setting Up Gradle Wrapper

If `gradlew` is missing, create it:

```bash
gradle wrapper --gradle-version 8.2
```

Or add these files manually (already included):
- `gradle/wrapper/gradle-wrapper.properties`
- `gradle/wrapper/gradle-wrapper.jar`

---

## Minimum Requirements

- **Android OS**: 8.0 (API 26) or higher
- **Bluetooth**: Required (Classic Bluetooth, not BLE-only)
- **RAM**: 2GB minimum recommended
- **Storage**: ~20MB for app install

---

## How It Works

### Bluetooth Mesh Network
Each device running MeshTalk acts as both a server and relay node:

1. **Discovery**: Devices scan for nearby Bluetooth devices every 60 seconds
2. **Connection**: Automatically connects to all discovered MeshTalk devices
3. **Mesh Routing**: Messages travel via multi-hop flooding with TTL
4. **Deduplication**: Each packet has a UUID to prevent loops

### Packet Types
| Type | Description |
|------|-------------|
| `TEXT_MESSAGE` | Chat message |
| `MESSAGE_ACK` | Delivery receipt |
| `PEER_ANNOUNCE` | Device presence broadcast |
| `CALL_INVITE` | Incoming call invitation |
| `CALL_ACCEPT/REJECT/END` | Call controls |
| `AUDIO_FRAME` | Base64-encoded PCM audio |

### Voice Calls
- Sample rate: 8000 Hz (8 kHz narrow-band)
- Format: 16-bit PCM
- Frame size: 20ms (320 samples)
- Audio encoded as Base64 and transmitted over mesh

---

## Architecture

```
MeshNetworkService (Foreground Service)
├── BluetoothConnectionManager  ← RFCOMM server + client connections
│   └── ConnectedThread (per peer)  ← Full-duplex I/O
├── BluetoothDiscovery  ← Device scanning + discoverability
├── MeshRouter  ← Packet routing, TTL, deduplication
└── AudioEngine  ← Microphone capture + speaker playback

UI Layer
├── SplashActivity → SetupActivity (first run)
├── MainActivity (bottom nav)
│   ├── NearbyFragment  ← Online/nearby contacts
│   └── ConversationsFragment  ← Chat history
├── ChatActivity  ← Text messaging
└── CallActivity  ← Voice call UI

Data Layer (Room)
├── Contact  ← Device registry
└── Message  ← Chat history
```

---

## Troubleshooting

**Devices can't find each other:**
- Both devices must have Bluetooth enabled
- Both devices must have MeshTalk running
- Grant all permissions (Bluetooth, Location) when prompted
- Make sure both devices are "discoverable" (the app requests this on startup)

**Voice call audio cuts out:**
- Direct Bluetooth connections work best for audio
- Audio is relayed through mesh but may have latency over multiple hops

**Pairing required:**
- Modern Android may require initial BT pairing between devices
- Complete the pairing prompt when it appears

---

## Permissions Used

| Permission | Reason |
|------------|--------|
| `BLUETOOTH_SCAN` | Find nearby devices |
| `BLUETOOTH_CONNECT` | Connect to devices |
| `BLUETOOTH_ADVERTISE` | Make device discoverable |
| `RECORD_AUDIO` | Voice calls |
| `FOREGROUND_SERVICE` | Keep mesh running in background |
| `ACCESS_FINE_LOCATION` | Required for BT scan on Android 11 and below |
