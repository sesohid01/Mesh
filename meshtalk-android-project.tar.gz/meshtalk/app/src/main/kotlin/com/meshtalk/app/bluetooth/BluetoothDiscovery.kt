package com.meshtalk.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * BluetoothDiscovery - manages device discovery and discoverability.
 *
 * Handles:
 * - Making this device discoverable to other MeshTalk nodes
 * - Scanning for nearby Bluetooth devices
 * - Filtering for MeshTalk-compatible devices
 */
@SuppressLint("MissingPermission")
class BluetoothDiscovery(
    private val context: Context,
    private val onDeviceFound: (BluetoothDevice) -> Unit
) {
    private val TAG = "BluetoothDiscovery"

    val bluetoothAdapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private val _discoveredDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<BluetoothDevice>> = _discoveredDevices

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering

    private var isReceiverRegistered = false

    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    device?.let { handleDeviceFound(it) }
                }
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    Log.d(TAG, "Discovery started")
                    _isDiscovering.value = true
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    Log.d(TAG, "Discovery finished")
                    _isDiscovering.value = false
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    Log.d(TAG, "Bluetooth state changed: $state")
                }
            }
        }
    }

    fun register() {
        if (isReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        context.registerReceiver(discoveryReceiver, filter)
        isReceiverRegistered = true
        Log.d(TAG, "BroadcastReceiver registered")
    }

    fun unregister() {
        if (!isReceiverRegistered) return
        try {
            context.unregisterReceiver(discoveryReceiver)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Receiver not registered")
        }
        isReceiverRegistered = false
    }

    fun startDiscovery() {
        if (bluetoothAdapter?.isEnabled != true) {
            Log.w(TAG, "Bluetooth is not enabled")
            return
        }
        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }
        _discoveredDevices.value = emptyList()
        bluetoothAdapter.startDiscovery()
        Log.d(TAG, "Started Bluetooth discovery")
    }

    fun stopDiscovery() {
        bluetoothAdapter?.cancelDiscovery()
        _isDiscovering.value = false
    }

    /**
     * Returns an Intent to request the device become discoverable.
     * This must be called by an Activity to show the system dialog.
     */
    fun makeDiscoverableIntent(durationSeconds: Int = 3600): Intent {
        return Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
            putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, durationSeconds)
        }
    }

    /**
     * Returns an Intent to request Bluetooth be enabled.
     */
    fun enableBluetoothIntent(): Intent {
        return Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
    }

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    fun isBluetoothSupported(): Boolean = bluetoothAdapter != null

    fun getBondedDevices(): List<BluetoothDevice> {
        return bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
    }

    private fun handleDeviceFound(device: BluetoothDevice) {
        val existing = _discoveredDevices.value
        if (existing.none { it.address == device.address }) {
            _discoveredDevices.value = existing + device
            Log.d(TAG, "Device found: ${device.name} (${device.address})")
            onDeviceFound(device)
        }
    }
}
