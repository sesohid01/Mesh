package com.meshtalk.app.ui.chat

import androidx.lifecycle.*
import com.meshtalk.app.data.dao.ContactDao
import com.meshtalk.app.data.dao.MessageDao
import com.meshtalk.app.data.entity.Contact
import com.meshtalk.app.data.entity.Message

class ChatViewModel(
    private val messageDao: MessageDao,
    private val contactDao: ContactDao,
    private val contactId: String
) : ViewModel() {

    val messages: LiveData<List<Message>> = messageDao.getMessagesForConversation(contactId)

    val contact: LiveData<Contact?> = liveData {
        emitSource(contactDao.getAllContacts().map { contacts ->
            contacts.firstOrNull { it.deviceId == contactId }
        })
    }
}

class ChatViewModelFactory(
    private val messageDao: MessageDao,
    private val contactDao: ContactDao,
    private val contactId: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(messageDao, contactDao, contactId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
