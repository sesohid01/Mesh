package com.meshtalk.app.mesh

import android.util.Log
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * MeshRouter - handles packet routing across the mesh network.
 *
 * Responsibilities:
 * - Track which packets have already been seen (deduplication)
 * - Decide whether to deliver locally or forward to other peers
 * - Maintain a routing table (node -> best next hop)
 * - Implement flooding with TTL for broadcast routing
 */
class MeshRouter(
    private val localDeviceId: String,
    private val scope: CoroutineScope,
    private val onDeliverLocally: (MeshPacket) -> Unit,
    private val onForwardToAll: (MeshPacket, excludeDeviceId: String?) -> Unit
) {
    private val TAG = "MeshRouter"
    private val gson = Gson()

    // Packet deduplication: packetId -> timestamp first seen
    private val seenPackets = ConcurrentHashMap<String, Long>()

    // Routing table: destinationDeviceId -> nextHopDeviceId
    private val routingTable = ConcurrentHashMap<String, String>()

    // Hop count cache: destinationDeviceId -> hops
    private val hopCount = ConcurrentHashMap<String, Int>()

    // Recently seen peers: deviceId -> lastSeen timestamp
    private val knownPeers = ConcurrentHashMap<String, PeerInfo>()

    init {
        // Periodically clean up old seen packets (older than 5 minutes)
        scope.launch(Dispatchers.IO) {
            while (true) {
                kotlinx.coroutines.delay(60_000L)
                val cutoff = System.currentTimeMillis() - 5 * 60 * 1000
                seenPackets.entries.removeIf { it.value < cutoff }
            }
        }
    }

    /**
     * Main entry point when a packet arrives from a connected peer.
     * @param packet The received packet
     * @param fromDeviceId The direct peer who sent us this packet
     */
    fun onPacketReceived(packet: MeshPacket, fromDeviceId: String) {
        // Deduplication check
        if (seenPackets.containsKey(packet.packetId)) {
            Log.d(TAG, "Dropping duplicate packet ${packet.packetId}")
            return
        }

        // Mark as seen
        seenPackets[packet.packetId] = System.currentTimeMillis()

        // Update routing table: we now know fromDeviceId can reach packet.senderId
        updateRoute(packet.senderId, fromDeviceId, packet.hopList.size)

        // Also update routes for all nodes in the hop list
        packet.hopList.forEachIndexed { index, hopId ->
            updateRoute(hopId, fromDeviceId, index + 1)
        }

        // Is this packet for us?
        if (packet.targetId == localDeviceId || packet.targetId == MeshPacket.BROADCAST) {
            Log.d(TAG, "Delivering packet ${packet.packetId} type=${packet.type} locally")
            onDeliverLocally(packet)
        }

        // Should we forward it?
        if (packet.targetId != localDeviceId) {
            forwardPacket(packet, fromDeviceId)
        }
    }

    /**
     * Send a new packet originating from this device.
     */
    fun sendPacket(packet: MeshPacket) {
        seenPackets[packet.packetId] = System.currentTimeMillis()

        if (packet.targetId == MeshPacket.BROADCAST) {
            // Broadcast to all peers
            onForwardToAll(packet, null)
        } else {
            // Unicast: look up best route or flood
            val nextHop = routingTable[packet.targetId]
            if (nextHop != null) {
                onForwardToAll(packet, null) // Forward toward known route
            } else {
                // No known route, flood
                onForwardToAll(packet, null)
            }
        }
    }

    private fun forwardPacket(packet: MeshPacket, fromDeviceId: String) {
        // Don't forward if TTL has expired
        if (packet.isExpired()) {
            Log.d(TAG, "Dropping expired packet ${packet.packetId} (TTL=0)")
            return
        }

        val forwarded = packet
            .withDecrementedTTL()
            .withAddedHop(localDeviceId)

        Log.d(TAG, "Forwarding packet ${packet.packetId} type=${packet.type} TTL=${forwarded.ttl}")

        if (packet.targetId == MeshPacket.BROADCAST) {
            // Flood to all except origin
            onForwardToAll(forwarded, fromDeviceId)
        } else {
            // Unicast: try to route to best next hop, else flood
            val nextHop = routingTable[packet.targetId]
            if (nextHop != null && nextHop != fromDeviceId) {
                onForwardToAll(forwarded, fromDeviceId)
            } else {
                onForwardToAll(forwarded, fromDeviceId)
            }
        }
    }

    private fun updateRoute(
        destination: String,
        viaNextHop: String,
        hops: Int
    ) {
        if (destination == localDeviceId) return

        val existingHops = hopCount[destination] ?: Int.MAX_VALUE
        if (hops < existingHops) {
            routingTable[destination] = viaNextHop
            hopCount[destination] = hops
            Log.d(TAG, "Route updated: $destination via $viaNextHop ($hops hops)")
        }
    }

    fun updatePeer(peer: PeerInfo) {
        knownPeers[peer.deviceId] = peer
    }

    fun removePeer(deviceId: String) {
        knownPeers.remove(deviceId)
        routingTable.entries.removeIf { it.value == deviceId }
    }

    fun getKnownPeers(): List<PeerInfo> = knownPeers.values.toList()

    fun getHopsTo(deviceId: String): Int = hopCount[deviceId] ?: Int.MAX_VALUE

    /**
     * Create a broadcast announce packet so other nodes know we exist.
     */
    fun createAnnouncePacket(displayName: String, btAddress: String): MeshPacket {
        val payload = PeerAnnouncePayload(
            deviceId = localDeviceId,
            displayName = displayName,
            bluetoothAddress = btAddress,
            timestamp = System.currentTimeMillis()
        )
        return MeshPacket(
            packetId = UUID.randomUUID().toString(),
            type = PacketType.PEER_ANNOUNCE,
            senderId = localDeviceId,
            targetId = MeshPacket.BROADCAST,
            payload = gson.toJson(payload),
            ttl = MeshPacket.MAX_TTL,
            timestamp = System.currentTimeMillis()
        )
    }

    /**
     * Create a text message packet.
     */
    fun createTextPacket(
        targetDeviceId: String,
        messageId: String,
        content: String,
        conversationId: String
    ): MeshPacket {
        val payload = TextMessagePayload(
            messageId = messageId,
            content = content,
            conversationId = conversationId
        )
        return MeshPacket(
            packetId = UUID.randomUUID().toString(),
            type = PacketType.TEXT_MESSAGE,
            senderId = localDeviceId,
            targetId = targetDeviceId,
            payload = gson.toJson(payload),
            ttl = MeshPacket.MAX_TTL,
            timestamp = System.currentTimeMillis()
        )
    }

    /**
     * Create a message acknowledgement packet.
     */
    fun createAckPacket(targetDeviceId: String, messageId: String): MeshPacket {
        val payload = MessageAckPayload(messageId = messageId, status = "DELIVERED")
        return MeshPacket(
            packetId = UUID.randomUUID().toString(),
            type = PacketType.MESSAGE_ACK,
            senderId = localDeviceId,
            targetId = targetDeviceId,
            payload = gson.toJson(payload),
            ttl = MeshPacket.MAX_TTL,
            timestamp = System.currentTimeMillis()
        )
    }

    /**
     * Create a call invite packet.
     */
    fun createCallInvitePacket(
        targetDeviceId: String,
        callId: String,
        callerName: String
    ): MeshPacket {
        val payload = CallPayload(callId = callId, callerName = callerName)
        return MeshPacket(
            packetId = UUID.randomUUID().toString(),
            type = PacketType.CALL_INVITE,
            senderId = localDeviceId,
            targetId = targetDeviceId,
            payload = gson.toJson(payload),
            ttl = MeshPacket.MAX_TTL,
            timestamp = System.currentTimeMillis()
        )
    }

    /**
     * Create a call response packet (accept/reject/end).
     */
    fun createCallResponsePacket(
        targetDeviceId: String,
        callId: String,
        type: PacketType
    ): MeshPacket {
        val payload = CallPayload(callId = callId, callerName = "")
        return MeshPacket(
            packetId = UUID.randomUUID().toString(),
            type = type,
            senderId = localDeviceId,
            targetId = targetDeviceId,
            payload = gson.toJson(payload),
            ttl = MeshPacket.MAX_TTL,
            timestamp = System.currentTimeMillis()
        )
    }

    /**
     * Create an audio frame packet for voice calls.
     * Uses lower TTL to reduce latency-sensitive flooding.
     */
    fun createAudioPacket(
        targetDeviceId: String,
        callId: String,
        frameIndex: Int,
        audioData: String
    ): MeshPacket {
        val payload = AudioFramePayload(
            callId = callId,
            frameIndex = frameIndex,
            audioData = audioData
        )
        return MeshPacket(
            packetId = UUID.randomUUID().toString(),
            type = PacketType.AUDIO_FRAME,
            senderId = localDeviceId,
            targetId = targetDeviceId,
            payload = gson.toJson(payload),
            ttl = 3,  // Short TTL for audio - reduce latency
            timestamp = System.currentTimeMillis()
        )
    }
}
