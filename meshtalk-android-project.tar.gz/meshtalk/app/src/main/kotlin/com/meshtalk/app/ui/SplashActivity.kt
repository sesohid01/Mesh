package com.meshtalk.app.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.meshtalk.app.ui.setup.SetupActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("meshtalk_prefs", Context.MODE_PRIVATE)
        val setupDone = prefs.getBoolean("setup_done", false)

        val nextActivity = if (setupDone) MainActivity::class.java else SetupActivity::class.java
        startActivity(Intent(this, nextActivity))
        finish()
    }
}
