package com.meshtalk.app.mesh

import com.google.gson.Gson

/**
 * MeshPacket - the core data unit transmitted between nodes.
 *
 * Every message (text, audio, control) is wrapped in a MeshPacket.
 * The mesh layer handles routing, deduplication, and forwarding.
 */
data class MeshPacket(
    val packetId: String,        // UUID for deduplication
    val type: PacketType,        // What kind of payload this is
    val senderId: String,        // Originating device ID
    val targetId: String,        // Final destination (or BROADCAST)
    val payload: String,         // JSON-encoded payload (type-specific)
    val ttl: Int,                // Time-to-live (hop count, decremented each hop)
    val timestamp: Long,         // Creation timestamp
    val hopList: List<String> = emptyList()  // List of device IDs that relayed this
) {
    fun toJson(): String = Gson().toJson(this)

    fun isExpired(): Boolean = ttl <= 0

    fun withDecrementedTTL(): MeshPacket = copy(ttl = ttl - 1)

    fun withAddedHop(deviceId: String): MeshPacket =
        copy(hopList = hopList + deviceId)

    companion object {
        const val BROADCAST = "BROADCAST"
        const val MAX_TTL = 7  // Maximum hops allowed

        fun fromJson(json: String): MeshPacket? = try {
            Gson().fromJson(json, MeshPacket::class.java)
        } catch (e: Exception) {
            null
        }
    }
}

enum class PacketType {
    TEXT_MESSAGE,        // Chat message
    MESSAGE_ACK,         // Delivery acknowledgement
    CALL_INVITE,         // Voice call invitation
    CALL_ACCEPT,         // Call accepted
    CALL_REJECT,         // Call rejected
    CALL_END,            // Call ended
    AUDIO_FRAME,         // Raw audio data chunk
    PEER_ANNOUNCE,       // Node announces itself to the mesh
    PEER_DISCOVER,       // Request for peer list
    PEER_LIST,           // Response with peer list
    HEARTBEAT,           // Keep-alive signal
    ROUTE_REQUEST,       // Find a path to a node
    ROUTE_REPLY          // Path found
}

// Payload classes for each packet type
data class TextMessagePayload(
    val messageId: String,
    val content: String,
    val conversationId: String
)

data class MessageAckPayload(
    val messageId: String,
    val status: String  // "DELIVERED"
)

data class CallPayload(
    val callId: String,
    val callerName: String
)

data class AudioFramePayload(
    val callId: String,
    val frameIndex: Int,
    val audioData: String  // Base64-encoded audio bytes
)

data class PeerAnnouncePayload(
    val deviceId: String,
    val displayName: String,
    val bluetoothAddress: String,
    val timestamp: Long
)

data class PeerListPayload(
    val peers: List<PeerInfo>
)

data class PeerInfo(
    val deviceId: String,
    val displayName: String,
    val hops: Int
)

data class RouteRequestPayload(
    val targetDeviceId: String,
    val requestId: String
)

data class RouteReplyPayload(
    val targetDeviceId: String,
    val requestId: String,
    val path: List<String>
)
