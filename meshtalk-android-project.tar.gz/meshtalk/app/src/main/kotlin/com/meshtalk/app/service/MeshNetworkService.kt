package com.meshtalk.app.service

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Binder
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.meshtalk.app.MeshTalkApplication
import com.meshtalk.app.R
import com.meshtalk.app.audio.AudioEngine
import com.meshtalk.app.bluetooth.BluetoothConnectionManager
import com.meshtalk.app.bluetooth.BluetoothDiscovery
import com.meshtalk.app.data.entity.Contact
import com.meshtalk.app.data.entity.Message
import com.meshtalk.app.data.entity.MessageStatus
import com.meshtalk.app.mesh.*
import com.meshtalk.app.ui.MainActivity
import com.meshtalk.app.ui.call.CallActivity
import com.meshtalk.app.utils.DeviceIdentity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

/**
 * MeshNetworkService - the core foreground service that keeps the mesh alive.
 *
 * This service:
 * - Manages Bluetooth connections (server + client)
 * - Runs the mesh router for packet forwarding
 * - Handles audio for voice calls
 * - Persists messages to the Room database
 * - Broadcasts state changes to the UI via LiveData/Flow
 */
@SuppressLint("MissingPermission")
class MeshNetworkService : LifecycleService() {
    private val TAG = "MeshNetworkService"
    private val gson = Gson()

    companion object {
        const val ACTION_SEND_MESSAGE = "com.meshtalk.ACTION_SEND_MESSAGE"
        const val ACTION_MAKE_CALL = "com.meshtalk.ACTION_MAKE_CALL"
        const val ACTION_ACCEPT_CALL = "com.meshtalk.ACTION_ACCEPT_CALL"
        const val ACTION_REJECT_CALL = "com.meshtalk.ACTION_REJECT_CALL"
        const val ACTION_END_CALL = "com.meshtalk.ACTION_END_CALL"
        const val ACTION_TOGGLE_MUTE = "com.meshtalk.ACTION_TOGGLE_MUTE"

        const val EXTRA_TARGET_DEVICE_ID = "target_device_id"
        const val EXTRA_MESSAGE_CONTENT = "message_content"
        const val EXTRA_CALL_ID = "call_id"

        const val NOTIFICATION_ID_SERVICE = 1
        const val NOTIFICATION_ID_INCOMING_CALL = 2

        // Flow/LiveData exposed to UI
        val connectedPeerCount = MutableStateFlow(0)
        val activeCallState = MutableStateFlow<CallState?>(null)
        val incomingCall = MutableStateFlow<IncomingCallInfo?>(null)
        val meshStatus = MutableStateFlow(MeshStatus.STARTING)
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var deviceId: String
    private lateinit var displayName: String

    private lateinit var connectionManager: BluetoothConnectionManager
    private lateinit var discovery: BluetoothDiscovery
    private lateinit var meshRouter: MeshRouter
    private lateinit var audioEngine: AudioEngine

    private val db by lazy { (application as MeshTalkApplication).database }

    // Current active call state
    private var currentCallId: String? = null
    private var currentCallPeerId: String? = null
    private var isCallActive = false

    // Discovery job
    private var discoveryJob: Job? = null
    private var heartbeatJob: Job? = null

    inner class LocalBinder : Binder() {
        fun getService(): MeshNetworkService = this@MeshNetworkService
    }

    private val binder = LocalBinder()

    override fun onBind(intent: Intent): IBinder {
        super.onBind(intent)
        return binder
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "MeshNetworkService created")

        prefs = getSharedPreferences("meshtalk_prefs", Context.MODE_PRIVATE)
        deviceId = DeviceIdentity.getDeviceId(this)
        displayName = prefs.getString("display_name", "User") ?: "User"

        audioEngine = AudioEngine(this)

        connectionManager = BluetoothConnectionManager(
            context = this,
            scope = lifecycleScope,
            onPacketReceived = ::handlePacketReceived,
            onPeerConnected = ::handlePeerConnected,
            onPeerDisconnected = ::handlePeerDisconnected
        )

        discovery = BluetoothDiscovery(
            context = this,
            onDeviceFound = ::handleDeviceFound
        )

        meshRouter = MeshRouter(
            localDeviceId = deviceId,
            scope = lifecycleScope,
            onDeliverLocally = ::deliverPacketLocally,
            onForwardToAll = { packet, excludeId ->
                val excludeAddress = if (excludeId != null)
                    connectionManager.getAddressForDeviceId(excludeId) else null
                connectionManager.broadcastPacket(packet, excludeAddress)
            }
        )

        startForeground(NOTIFICATION_ID_SERVICE, buildServiceNotification())
        meshStatus.value = MeshStatus.RUNNING

        startBluetoothMesh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_SEND_MESSAGE -> {
                val targetId = intent.getStringExtra(EXTRA_TARGET_DEVICE_ID) ?: return START_STICKY
                val content = intent.getStringExtra(EXTRA_MESSAGE_CONTENT) ?: return START_STICKY
                sendTextMessage(targetId, content)
            }
            ACTION_MAKE_CALL -> {
                val targetId = intent.getStringExtra(EXTRA_TARGET_DEVICE_ID) ?: return START_STICKY
                initiateCall(targetId)
            }
            ACTION_ACCEPT_CALL -> acceptCurrentCall()
            ACTION_REJECT_CALL -> rejectCurrentCall()
            ACTION_END_CALL -> endCurrentCall()
            ACTION_TOGGLE_MUTE -> toggleMute()
        }

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "MeshNetworkService destroyed")
        discoveryJob?.cancel()
        heartbeatJob?.cancel()
        discovery.stopDiscovery()
        discovery.unregister()
        connectionManager.stop()
        audioEngine.stop()
        meshStatus.value = MeshStatus.STOPPED
    }

    private fun startBluetoothMesh() {
        if (!discovery.isBluetoothEnabled()) {
            Log.w(TAG, "Bluetooth not enabled, mesh not started")
            meshStatus.value = MeshStatus.BLUETOOTH_DISABLED
            return
        }

        discovery.register()
        connectionManager.start()

        // Try to connect to already-bonded devices first
        val bondedDevices = discovery.getBondedDevices()
        bondedDevices.forEach { device ->
            lifecycleScope.launch(Dispatchers.IO) {
                delay(500)
                connectionManager.connectToDevice(device)
            }
        }

        // Periodically scan for new devices
        discoveryJob = lifecycleScope.launch {
            while (isActive) {
                discovery.startDiscovery()
                delay(60_000L)  // Scan every 60 seconds
                discovery.stopDiscovery()
                delay(5_000L)
            }
        }

        // Send heartbeat / announce regularly
        heartbeatJob = lifecycleScope.launch {
            delay(2000)
            while (isActive) {
                announcePresence()
                delay(30_000L)
            }
        }

        Log.i(TAG, "Bluetooth mesh started. Local device: $deviceId ($displayName)")
    }

    private fun announcePresence() {
        val btAddress = discovery.bluetoothAdapter?.address ?: "00:00:00:00:00:00"
        val packet = meshRouter.createAnnouncePacket(displayName, btAddress)
        meshRouter.sendPacket(packet)
        Log.d(TAG, "Announced presence to mesh")
    }

    // ── Packet Handlers ──────────────────────────────────────────────────────

    private fun handlePacketReceived(packet: MeshPacket, fromDeviceId: String) {
        meshRouter.onPacketReceived(packet, fromDeviceId)
    }

    private fun deliverPacketLocally(packet: MeshPacket) {
        when (packet.type) {
            PacketType.TEXT_MESSAGE -> handleIncomingText(packet)
            PacketType.MESSAGE_ACK -> handleMessageAck(packet)
            PacketType.PEER_ANNOUNCE -> handlePeerAnnounce(packet)
            PacketType.CALL_INVITE -> handleCallInvite(packet)
            PacketType.CALL_ACCEPT -> handleCallAccepted(packet)
            PacketType.CALL_REJECT -> handleCallRejected(packet)
            PacketType.CALL_END -> handleCallEnded(packet)
            PacketType.AUDIO_FRAME -> handleAudioFrame(packet)
            PacketType.HEARTBEAT -> {} // Just used for routing table updates
            else -> {}
        }
    }

    private fun handleIncomingText(packet: MeshPacket) {
        try {
            val payload = gson.fromJson(packet.payload, TextMessagePayload::class.java)
            Log.i(TAG, "Received text message from ${packet.senderId}: ${payload.content}")

            val message = Message(
                messageId = payload.messageId,
                conversationId = packet.senderId,
                senderId = packet.senderId,
                receiverId = deviceId,
                content = payload.content,
                timestamp = packet.timestamp,
                status = MessageStatus.DELIVERED,
                isMine = false
            )

            lifecycleScope.launch(Dispatchers.IO) {
                db.messageDao().insertMessage(message)

                // Update/insert contact record
                var contact = db.contactDao().getContactById(packet.senderId)
                if (contact == null) {
                    contact = Contact(
                        deviceId = packet.senderId,
                        name = "Unknown",
                        bluetoothAddress = "",
                        lastSeen = packet.timestamp,
                        isOnline = true
                    )
                    db.contactDao().insertContact(contact)
                }

                // Send delivery ACK
                val ackPacket = meshRouter.createAckPacket(packet.senderId, payload.messageId)
                meshRouter.sendPacket(ackPacket)
            }

            showMessageNotification(packet.senderId, payload.content)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling text message: ${e.message}")
        }
    }

    private fun handleMessageAck(packet: MeshPacket) {
        try {
            val payload = gson.fromJson(packet.payload, MessageAckPayload::class.java)
            Log.d(TAG, "Message ${payload.messageId} delivered to ${packet.senderId}")

            lifecycleScope.launch(Dispatchers.IO) {
                db.messageDao().updateMessageStatus(payload.messageId, MessageStatus.DELIVERED)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling message ACK: ${e.message}")
        }
    }

    private fun handlePeerAnnounce(packet: MeshPacket) {
        try {
            val payload = gson.fromJson(packet.payload, PeerAnnouncePayload::class.java)
            if (payload.deviceId == deviceId) return  // Ignore our own broadcasts

            Log.d(TAG, "Peer announced: ${payload.displayName} (${payload.deviceId})")

            val hops = meshRouter.getHopsTo(payload.deviceId)

            meshRouter.updatePeer(PeerInfo(
                deviceId = payload.deviceId,
                displayName = payload.displayName,
                hops = hops
            ))

            lifecycleScope.launch(Dispatchers.IO) {
                val existing = db.contactDao().getContactById(payload.deviceId)
                if (existing == null) {
                    val contact = Contact(
                        deviceId = payload.deviceId,
                        name = payload.displayName,
                        bluetoothAddress = payload.bluetoothAddress,
                        lastSeen = packet.timestamp,
                        isOnline = true,
                        hops = hops
                    )
                    db.contactDao().insertContact(contact)
                } else {
                    db.contactDao().updateOnlineStatus(
                        payload.deviceId, true, hops, System.currentTimeMillis()
                    )
                }
            }

            connectedPeerCount.value = connectionManager.getConnectedCount()
            connectionManager.registerDeviceId(payload.bluetoothAddress, payload.deviceId)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling peer announce: ${e.message}")
        }
    }

    private fun handleCallInvite(packet: MeshPacket) {
        try {
            val payload = gson.fromJson(packet.payload, CallPayload::class.java)
            Log.i(TAG, "Incoming call from ${packet.senderId} (${payload.callerName})")

            if (isCallActive) {
                // Auto-reject if busy
                val rejectPacket = meshRouter.createCallResponsePacket(
                    packet.senderId, payload.callId, PacketType.CALL_REJECT
                )
                meshRouter.sendPacket(rejectPacket)
                return
            }

            incomingCall.value = IncomingCallInfo(
                callId = payload.callId,
                callerId = packet.senderId,
                callerName = payload.callerName
            )

            showIncomingCallNotification(payload.callerName, payload.callId)

            // Launch incoming call UI
            val callIntent = Intent(this, CallActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(CallActivity.EXTRA_IS_INCOMING, true)
                putExtra(CallActivity.EXTRA_CALL_ID, payload.callId)
                putExtra(CallActivity.EXTRA_PEER_ID, packet.senderId)
                putExtra(CallActivity.EXTRA_PEER_NAME, payload.callerName)
            }
            startActivity(callIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling call invite: ${e.message}")
        }
    }

    private fun handleCallAccepted(packet: MeshPacket) {
        try {
            val payload = gson.fromJson(packet.payload, CallPayload::class.java)
            if (payload.callId != currentCallId) return

            Log.i(TAG, "Call accepted by ${packet.senderId}")
            isCallActive = true

            activeCallState.value = CallState(
                callId = payload.callId,
                peerId = packet.senderId,
                state = CallStateEnum.ACTIVE,
                isMuted = false
            )

            startAudioCapture()
        } catch (e: Exception) {
            Log.e(TAG, "Error handling call accept: ${e.message}")
        }
    }

    private fun handleCallRejected(packet: MeshPacket) {
        try {
            val payload = gson.fromJson(packet.payload, CallPayload::class.java)
            if (payload.callId != currentCallId) return

            Log.i(TAG, "Call rejected by ${packet.senderId}")
            cleanupCall()
        } catch (e: Exception) {
            Log.e(TAG, "Error handling call reject: ${e.message}")
        }
    }

    private fun handleCallEnded(packet: MeshPacket) {
        try {
            val payload = gson.fromJson(packet.payload, CallPayload::class.java)
            if (payload.callId != currentCallId) return

            Log.i(TAG, "Call ended by ${packet.senderId}")
            cleanupCall()
        } catch (e: Exception) {
            Log.e(TAG, "Error handling call end: ${e.message}")
        }
    }

    private fun handleAudioFrame(packet: MeshPacket) {
        if (!isCallActive || packet.senderId != currentCallPeerId) return

        try {
            val payload = gson.fromJson(packet.payload, AudioFramePayload::class.java)
            if (payload.callId != currentCallId) return
            audioEngine.queueAudioFrame(payload.audioData)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling audio frame: ${e.message}")
        }
    }

    // ── Connection Handlers ──────────────────────────────────────────────────

    private fun handlePeerConnected(deviceId: String, address: String, name: String) {
        Log.i(TAG, "Peer connected: $name ($deviceId at $address)")
        connectedPeerCount.value = connectionManager.getConnectedCount()
        // Immediately announce our presence to the new peer
        announcePresence()
    }

    private fun handlePeerDisconnected(deviceId: String) {
        Log.i(TAG, "Peer disconnected: $deviceId")
        connectedPeerCount.value = connectionManager.getConnectedCount()
        meshRouter.removePeer(deviceId)

        lifecycleScope.launch(Dispatchers.IO) {
            db.contactDao().updateOnlineStatus(deviceId, false, 0, System.currentTimeMillis())
        }

        if (deviceId == currentCallPeerId && isCallActive) {
            cleanupCall()
        }
    }

    private fun handleDeviceFound(device: BluetoothDevice) {
        // Auto-connect to discovered devices
        if (!connectionManager.isConnectedTo(device.address)) {
            connectionManager.connectToDevice(device)
        }
    }

    // ── Public API ───────────────────────────────────────────────────────────

    fun sendTextMessage(targetDeviceId: String, content: String) {
        val messageId = UUID.randomUUID().toString()
        val packet = meshRouter.createTextPacket(
            targetDeviceId = targetDeviceId,
            messageId = messageId,
            content = content,
            conversationId = targetDeviceId
        )

        val message = Message(
            messageId = messageId,
            conversationId = targetDeviceId,
            senderId = deviceId,
            receiverId = targetDeviceId,
            content = content,
            timestamp = System.currentTimeMillis(),
            status = MessageStatus.SENDING,
            isMine = true
        )

        lifecycleScope.launch(Dispatchers.IO) {
            db.messageDao().insertMessage(message)
            meshRouter.sendPacket(packet)
            db.messageDao().updateMessageStatus(messageId, MessageStatus.SENT)
        }
    }

    fun initiateCall(targetDeviceId: String) {
        if (isCallActive) return

        currentCallId = UUID.randomUUID().toString()
        currentCallPeerId = targetDeviceId

        activeCallState.value = CallState(
            callId = currentCallId!!,
            peerId = targetDeviceId,
            state = CallStateEnum.CALLING,
            isMuted = false
        )

        val packet = meshRouter.createCallInvitePacket(
            targetDeviceId = targetDeviceId,
            callId = currentCallId!!,
            callerName = displayName
        )
        meshRouter.sendPacket(packet)
        Log.i(TAG, "Call initiated to $targetDeviceId (callId=$currentCallId)")
    }

    fun acceptCurrentCall() {
        val incoming = incomingCall.value ?: return

        currentCallId = incoming.callId
        currentCallPeerId = incoming.callerId
        isCallActive = true
        incomingCall.value = null

        val packet = meshRouter.createCallResponsePacket(
            targetDeviceId = incoming.callerId,
            callId = incoming.callId,
            type = PacketType.CALL_ACCEPT
        )
        meshRouter.sendPacket(packet)

        activeCallState.value = CallState(
            callId = incoming.callId,
            peerId = incoming.callerId,
            state = CallStateEnum.ACTIVE,
            isMuted = false
        )

        startAudioCapture()
        Log.i(TAG, "Call accepted (callId=${incoming.callId})")
    }

    fun rejectCurrentCall() {
        val incoming = incomingCall.value ?: return

        val packet = meshRouter.createCallResponsePacket(
            targetDeviceId = incoming.callerId,
            callId = incoming.callId,
            type = PacketType.CALL_REJECT
        )
        meshRouter.sendPacket(packet)
        incomingCall.value = null
        Log.i(TAG, "Call rejected")
    }

    fun endCurrentCall() {
        val callId = currentCallId ?: return
        val peerId = currentCallPeerId ?: return

        val packet = meshRouter.createCallResponsePacket(
            targetDeviceId = peerId,
            callId = callId,
            type = PacketType.CALL_END
        )
        meshRouter.sendPacket(packet)
        cleanupCall()
        Log.i(TAG, "Call ended")
    }

    fun toggleMute() {
        val muted = !audioEngine.isMuted()
        audioEngine.setMuted(muted)

        activeCallState.value = activeCallState.value?.copy(isMuted = muted)
        Log.d(TAG, "Mute toggled: $muted")
    }

    fun updateDisplayName(name: String) {
        displayName = name
        prefs.edit().putString("display_name", name).apply()
    }

    fun getLocalDeviceId(): String = deviceId

    fun getDisplayName(): String = displayName

    // ── Audio ────────────────────────────────────────────────────────────────

    private fun startAudioCapture() {
        audioEngine.setCallAudioMode()
        audioEngine.startPlayback(lifecycleScope)
        audioEngine.onAudioFrame = { audioData, frameIndex ->
            val encodedData = audioEngine.encodeAudioFrame(audioData)
            val packet = meshRouter.createAudioPacket(
                targetDeviceId = currentCallPeerId!!,
                callId = currentCallId!!,
                frameIndex = frameIndex,
                audioData = encodedData
            )
            meshRouter.sendPacket(packet)
        }
        audioEngine.startCapture(lifecycleScope)
    }

    private fun cleanupCall() {
        isCallActive = false
        currentCallId = null
        currentCallPeerId = null

        audioEngine.stop()
        audioEngine.restoreAudioMode()

        activeCallState.value = null
        incomingCall.value = null

        (getSystemService(NotificationManager::class.java))
            ?.cancel(NOTIFICATION_ID_INCOMING_CALL)

        Log.i(TAG, "Call cleanup done")
    }

    // ── Notifications ────────────────────────────────────────────────────────

    private fun buildServiceNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, MeshTalkApplication.CHANNEL_MESH_SERVICE)
            .setContentTitle("MeshTalk")
            .setContentText("Bluetooth mesh network active")
            .setSmallIcon(R.drawable.ic_mesh)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun showMessageNotification(senderId: String, content: String) {
        val notificationManager = getSystemService(NotificationManager::class.java)
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("open_chat", senderId)
        }
        val pendingIntent = PendingIntent.getActivity(
            this, senderId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, MeshTalkApplication.CHANNEL_MESSAGES)
            .setContentTitle("New Message")
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_message)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(senderId.hashCode(), notification)
    }

    private fun showIncomingCallNotification(callerName: String, callId: String) {
        val notificationManager = getSystemService(NotificationManager::class.java)
        val notification = NotificationCompat.Builder(this, MeshTalkApplication.CHANNEL_CALLS)
            .setContentTitle("Incoming Call")
            .setContentText("$callerName is calling...")
            .setSmallIcon(R.drawable.ic_call)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID_INCOMING_CALL, notification)
    }
}

// State classes
data class CallState(
    val callId: String,
    val peerId: String,
    val state: CallStateEnum,
    val isMuted: Boolean
)

enum class CallStateEnum {
    CALLING,    // We called, waiting for accept
    ACTIVE,     // Call connected
    ENDED
}

data class IncomingCallInfo(
    val callId: String,
    val callerId: String,
    val callerName: String
)

enum class MeshStatus {
    STARTING,
    RUNNING,
    BLUETOOTH_DISABLED,
    STOPPED
}
