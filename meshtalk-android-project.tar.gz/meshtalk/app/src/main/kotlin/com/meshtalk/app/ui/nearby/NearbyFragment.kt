package com.meshtalk.app.ui.nearby

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.meshtalk.app.MeshTalkApplication
import com.meshtalk.app.databinding.FragmentNearbyBinding
import com.meshtalk.app.ui.chat.ChatActivity
import com.meshtalk.app.ui.nearby.adapter.NearbyAdapter

class NearbyFragment : Fragment() {

    private var _binding: FragmentNearbyBinding? = null
    private val binding get() = _binding!!

    private val viewModel: NearbyViewModel by viewModels {
        NearbyViewModelFactory(
            (requireActivity().application as MeshTalkApplication).database.contactDao()
        )
    }

    private lateinit var adapter: NearbyAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNearbyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = NearbyAdapter { contact ->
            val intent = Intent(requireContext(), ChatActivity::class.java).apply {
                putExtra(ChatActivity.EXTRA_CONTACT_ID, contact.deviceId)
                putExtra(ChatActivity.EXTRA_CONTACT_NAME, contact.name)
            }
            startActivity(intent)
        }

        binding.rvNearby.apply {
            layoutManager = LinearLayoutManager(context)
            this.adapter = this@NearbyFragment.adapter
        }

        viewModel.nearbyContacts.observe(viewLifecycleOwner) { contacts ->
            adapter.submitList(contacts)
            binding.tvEmptyState.visibility = if (contacts.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.swipeRefresh.setOnRefreshListener {
            binding.swipeRefresh.isRefreshing = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
