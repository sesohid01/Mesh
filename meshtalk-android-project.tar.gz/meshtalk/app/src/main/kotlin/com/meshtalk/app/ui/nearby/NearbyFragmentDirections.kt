package com.meshtalk.app.ui.nearby

import android.content.Intent
import android.os.Bundle
import androidx.navigation.NavDirections
import com.meshtalk.app.ui.chat.ChatActivity

// Navigation directions for NearbyFragment
class NearbyFragmentDirections {
    companion object {
        fun actionNearbyToChat(contactId: String, contactName: String): NavDirections {
            return object : NavDirections {
                override val actionId: Int = com.meshtalk.app.R.id.action_nearby_to_chat
                override val arguments: Bundle = Bundle().apply {
                    putString("contactId", contactId)
                    putString("contactName", contactName)
                }
            }
        }
    }
}
