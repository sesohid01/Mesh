package com.meshtalk.app.ui.nearby

import androidx.lifecycle.*
import com.meshtalk.app.data.dao.ContactDao
import com.meshtalk.app.data.entity.Contact

class NearbyViewModel(private val contactDao: ContactDao) : ViewModel() {
    val nearbyContacts: LiveData<List<Contact>> = contactDao.getAllContacts()
}

class NearbyViewModelFactory(private val contactDao: ContactDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NearbyViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NearbyViewModel(contactDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
