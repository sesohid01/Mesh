package com.meshtalk.app.ui.nearby.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.meshtalk.app.data.entity.Contact
import com.meshtalk.app.databinding.ItemNearbyContactBinding

class NearbyAdapter(
    private val onContactClicked: (Contact) -> Unit
) : ListAdapter<Contact, NearbyAdapter.ContactViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val binding = ItemNearbyContactBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ContactViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ContactViewHolder(
        private val binding: ItemNearbyContactBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(contact: Contact) {
            binding.tvName.text = contact.name
            binding.tvDeviceId.text = contact.deviceId

            if (contact.isOnline) {
                if (contact.hops == 0) {
                    binding.tvStatus.text = "Direct connection"
                } else {
                    binding.tvStatus.text = "${contact.hops} hop${if (contact.hops > 1) "s" else ""} away"
                }
                binding.ivStatus.setImageResource(com.meshtalk.app.R.drawable.ic_online)
            } else {
                binding.tvStatus.text = "Offline"
                binding.ivStatus.setImageResource(com.meshtalk.app.R.drawable.ic_offline)
            }

            binding.tvInitial.text = contact.name.firstOrNull()?.uppercase() ?: "?"

            binding.root.setOnClickListener {
                onContactClicked(contact)
            }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Contact>() {
            override fun areItemsTheSame(oldItem: Contact, newItem: Contact) =
                oldItem.deviceId == newItem.deviceId

            override fun areContentsTheSame(oldItem: Contact, newItem: Contact) =
                oldItem == newItem
        }
    }
}
