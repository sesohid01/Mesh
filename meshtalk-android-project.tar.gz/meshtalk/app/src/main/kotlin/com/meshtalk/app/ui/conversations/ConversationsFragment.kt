package com.meshtalk.app.ui.conversations

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.meshtalk.app.MeshTalkApplication
import com.meshtalk.app.databinding.FragmentConversationsBinding
import com.meshtalk.app.ui.chat.ChatActivity
import com.meshtalk.app.ui.conversations.adapter.ConversationsAdapter

class ConversationsFragment : Fragment() {

    private var _binding: FragmentConversationsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ConversationsViewModel by viewModels {
        ConversationsViewModelFactory(
            (requireActivity().application as MeshTalkApplication).database.messageDao(),
            (requireActivity().application as MeshTalkApplication).database.contactDao()
        )
    }

    private lateinit var adapter: ConversationsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentConversationsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ConversationsAdapter { contactId, contactName ->
            val intent = Intent(requireContext(), ChatActivity::class.java).apply {
                putExtra(ChatActivity.EXTRA_CONTACT_ID, contactId)
                putExtra(ChatActivity.EXTRA_CONTACT_NAME, contactName)
            }
            startActivity(intent)
        }

        binding.rvConversations.apply {
            layoutManager = LinearLayoutManager(context)
            this.adapter = this@ConversationsFragment.adapter
        }

        viewModel.conversations.observe(viewLifecycleOwner) { conversations ->
            adapter.submitList(conversations)
            binding.tvEmptyState.visibility = if (conversations.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
