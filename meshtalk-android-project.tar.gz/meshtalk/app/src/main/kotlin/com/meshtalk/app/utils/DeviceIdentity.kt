package com.meshtalk.app.utils

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

/**
 * DeviceIdentity - provides a stable, unique identifier for this device.
 *
 * We can't reliably use BT MAC addresses on modern Android (they're randomized),
 * so we generate and persist a UUID on first run.
 */
object DeviceIdentity {

    private const val PREF_NAME = "device_identity"
    private const val KEY_DEVICE_ID = "device_id"

    @Volatile
    private var cachedId: String? = null

    fun getDeviceId(context: Context): String {
        cachedId?.let { return it }

        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        var id = prefs.getString(KEY_DEVICE_ID, null)

        if (id == null) {
            id = UUID.randomUUID().toString().replace("-", "").substring(0, 16).uppercase()
            prefs.edit().putString(KEY_DEVICE_ID, id).apply()
        }

        cachedId = id
        return id
    }
}
