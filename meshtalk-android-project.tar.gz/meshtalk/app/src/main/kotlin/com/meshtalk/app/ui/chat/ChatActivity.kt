package com.meshtalk.app.ui.chat

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.inputmethod.EditorInfo
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.meshtalk.app.MeshTalkApplication
import com.meshtalk.app.databinding.ActivityChatBinding
import com.meshtalk.app.service.MeshNetworkService
import com.meshtalk.app.ui.call.CallActivity
import com.meshtalk.app.ui.chat.adapter.MessageAdapter
import com.meshtalk.app.utils.DeviceIdentity

class ChatActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CONTACT_ID = "contact_id"
        const val EXTRA_CONTACT_NAME = "contact_name"
    }

    private lateinit var binding: ActivityChatBinding
    private lateinit var contactId: String
    private lateinit var contactName: String

    private val viewModel: ChatViewModel by viewModels {
        ChatViewModelFactory(
            (application as MeshTalkApplication).database.messageDao(),
            (application as MeshTalkApplication).database.contactDao(),
            contactId
        )
    }

    private lateinit var messageAdapter: MessageAdapter
    private var meshService: MeshNetworkService? = null
    private var isServiceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            meshService = (service as? MeshNetworkService.LocalBinder)?.getService()
            isServiceBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            meshService = null
            isServiceBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        contactId = intent.getStringExtra(EXTRA_CONTACT_ID) ?: run { finish(); return }
        contactName = intent.getStringExtra(EXTRA_CONTACT_NAME) ?: "Unknown"

        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = contactName
        }

        val localDeviceId = DeviceIdentity.getDeviceId(this)
        messageAdapter = MessageAdapter(localDeviceId)

        binding.rvMessages.apply {
            layoutManager = LinearLayoutManager(context).apply {
                stackFromEnd = true
            }
            adapter = messageAdapter
        }

        viewModel.messages.observe(this) { messages ->
            messageAdapter.submitList(messages) {
                if (messages.isNotEmpty()) {
                    binding.rvMessages.scrollToPosition(messages.size - 1)
                }
            }
        }

        viewModel.contact.observe(this) { contact ->
            contact?.let {
                binding.tvStatus.text = if (it.isOnline) {
                    if (it.hops == 0) "Direct connection" else "${it.hops} hop(s) away"
                } else "Offline"
            }
        }

        binding.btnSend.setOnClickListener { sendMessage() }

        binding.etMessage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else false
        }

        binding.btnCall.setOnClickListener {
            val callIntent = Intent(this, CallActivity::class.java).apply {
                putExtra(CallActivity.EXTRA_IS_INCOMING, false)
                putExtra(CallActivity.EXTRA_PEER_ID, contactId)
                putExtra(CallActivity.EXTRA_PEER_NAME, contactName)
            }
            startActivity(callIntent)
        }

        bindService(
            Intent(this, MeshNetworkService::class.java),
            serviceConnection,
            Context.BIND_AUTO_CREATE
        )
    }

    private fun sendMessage() {
        val content = binding.etMessage.text?.toString()?.trim() ?: return
        if (content.isBlank()) return

        binding.etMessage.setText("")

        // Send via service
        val intent = Intent(this, MeshNetworkService::class.java).apply {
            action = MeshNetworkService.ACTION_SEND_MESSAGE
            putExtra(MeshNetworkService.EXTRA_TARGET_DEVICE_ID, contactId)
            putExtra(MeshNetworkService.EXTRA_MESSAGE_CONTENT, content)
        }
        startService(intent)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isServiceBound) {
            unbindService(serviceConnection)
        }
    }
}
