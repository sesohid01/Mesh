package com.meshtalk.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.util.Log
import com.meshtalk.app.mesh.MeshPacket
import kotlinx.coroutines.*
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * BluetoothConnectionManager - manages BT Classic RFCOMM connections.
 *
 * Acts as both a server (accepting connections) and a client (connecting to peers).
 * Each connected peer gets a ConnectedThread for full-duplex communication.
 */
@SuppressLint("MissingPermission")
class BluetoothConnectionManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onPacketReceived: (MeshPacket, fromDeviceId: String) -> Unit,
    private val onPeerConnected: (deviceId: String, address: String, name: String) -> Unit,
    private val onPeerDisconnected: (deviceId: String) -> Unit
) {
    private val TAG = "BluetoothConnManager"

    companion object {
        // Service UUID for MeshTalk - must be identical across all devices
        val MESHTALK_UUID: UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66")
        const val SERVICE_NAME = "MeshTalk"
        const val MAX_CONNECTIONS = 7  // BT Classic practical limit
    }

    private val bluetoothAdapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    // Active connections: deviceAddress -> ConnectedThread
    private val connections = ConcurrentHashMap<String, ConnectedThread>()

    // Device address to deviceId mapping (populated from announce packets)
    private val addressToDeviceId = ConcurrentHashMap<String, String>()

    private var acceptThread: AcceptThread? = null
    private var isRunning = false

    /**
     * Start the server and begin accepting connections.
     */
    fun start() {
        if (isRunning) return
        isRunning = true
        stopAccepting()
        acceptThread = AcceptThread()
        acceptThread?.start()
        Log.i(TAG, "BluetoothConnectionManager started, listening for connections")
    }

    fun stop() {
        isRunning = false
        stopAccepting()
        disconnectAll()
        Log.i(TAG, "BluetoothConnectionManager stopped")
    }

    private fun stopAccepting() {
        acceptThread?.cancel()
        acceptThread = null
    }

    /**
     * Connect to a remote Bluetooth device.
     */
    fun connectToDevice(device: BluetoothDevice) {
        val address = device.address
        if (connections.containsKey(address)) {
            Log.d(TAG, "Already connected to $address")
            return
        }

        scope.launch(Dispatchers.IO) {
            try {
                Log.d(TAG, "Connecting to ${device.name} ($address)")
                val socket = device.createRfcommSocketToServiceRecord(MESHTALK_UUID)
                bluetoothAdapter?.cancelDiscovery()
                socket.connect()
                Log.i(TAG, "Connected to ${device.name} ($address)")

                val thread = ConnectedThread(socket, address)
                connections[address] = thread
                thread.start()

                val deviceId = addressToDeviceId[address] ?: address
                onPeerConnected(deviceId, address, device.name ?: "Unknown")
            } catch (e: IOException) {
                Log.e(TAG, "Failed to connect to $address: ${e.message}")
            }
        }
    }

    /**
     * Send a packet to a specific peer by device address.
     */
    fun sendToAddress(address: String, packet: MeshPacket) {
        connections[address]?.write(packet.toJson())
    }

    /**
     * Broadcast a packet to all connected peers, optionally excluding one.
     */
    fun broadcastPacket(packet: MeshPacket, excludeAddress: String? = null) {
        val data = packet.toJson()
        connections.forEach { (address, thread) ->
            if (address != excludeAddress) {
                thread.write(data)
            }
        }
    }

    fun getConnectedAddresses(): List<String> = connections.keys.toList()

    fun getConnectedCount(): Int = connections.size

    fun isConnectedTo(address: String): Boolean = connections.containsKey(address)

    fun registerDeviceId(address: String, deviceId: String) {
        addressToDeviceId[address] = deviceId
    }

    fun getAddressForDeviceId(deviceId: String): String? {
        return addressToDeviceId.entries.firstOrNull { it.value == deviceId }?.key
    }

    private fun disconnectAll() {
        connections.forEach { (_, thread) -> thread.cancel() }
        connections.clear()
    }

    private fun onConnectionLost(address: String) {
        connections.remove(address)
        val deviceId = addressToDeviceId[address] ?: address
        Log.i(TAG, "Connection lost to $deviceId ($address)")
        onPeerDisconnected(deviceId)
    }

    /**
     * Server thread: listens for incoming Bluetooth connections.
     */
    private inner class AcceptThread : Thread() {
        private val serverSocket: BluetoothServerSocket? = try {
            bluetoothAdapter?.listenUsingRfcommWithServiceRecord(SERVICE_NAME, MESHTALK_UUID)
        } catch (e: IOException) {
            Log.e(TAG, "Failed to create server socket: ${e.message}")
            null
        }

        override fun run() {
            Log.d(TAG, "AcceptThread started")
            while (isRunning) {
                try {
                    val socket = serverSocket?.accept() ?: break
                    val address = socket.remoteDevice.address

                    Log.i(TAG, "Accepted connection from $address")

                    val thread = ConnectedThread(socket, address)
                    connections[address] = thread
                    thread.start()

                    val deviceId = addressToDeviceId[address] ?: address
                    onPeerConnected(deviceId, address, socket.remoteDevice.name ?: "Unknown")
                } catch (e: IOException) {
                    if (isRunning) {
                        Log.e(TAG, "AcceptThread error: ${e.message}")
                    }
                    break
                }
            }
            Log.d(TAG, "AcceptThread ended")
        }

        fun cancel() {
            try {
                serverSocket?.close()
            } catch (e: IOException) {
                Log.e(TAG, "Error closing server socket: ${e.message}")
            }
        }
    }

    /**
     * Connected thread: handles I/O for a single peer connection.
     */
    private inner class ConnectedThread(
        private val socket: BluetoothSocket,
        private val address: String
    ) : Thread() {

        private val inputStream: InputStream? = try { socket.inputStream } catch (e: IOException) { null }
        private val outputStream: OutputStream? = try { socket.outputStream } catch (e: IOException) { null }

        override fun run() {
            val buffer = StringBuilder()
            val readBuffer = ByteArray(4096)

            while (true) {
                try {
                    val bytesRead = inputStream?.read(readBuffer) ?: break
                    if (bytesRead == -1) break

                    buffer.append(String(readBuffer, 0, bytesRead, Charsets.UTF_8))

                    // Process complete JSON objects (newline-delimited)
                    var newlineIdx = buffer.indexOf('\n')
                    while (newlineIdx >= 0) {
                        val jsonStr = buffer.substring(0, newlineIdx).trim()
                        buffer.delete(0, newlineIdx + 1)

                        if (jsonStr.isNotEmpty()) {
                            val packet = MeshPacket.fromJson(jsonStr)
                            if (packet != null) {
                                val fromDeviceId = addressToDeviceId[address] ?: address
                                // Register device ID if this is an announce packet
                                if (packet.type == com.meshtalk.app.mesh.PacketType.PEER_ANNOUNCE) {
                                    addressToDeviceId[address] = packet.senderId
                                }
                                onPacketReceived(packet, fromDeviceId)
                            }
                        }
                        newlineIdx = buffer.indexOf('\n')
                    }
                } catch (e: IOException) {
                    Log.d(TAG, "Connection to $address lost: ${e.message}")
                    break
                }
            }
            onConnectionLost(address)
        }

        fun write(data: String) {
            try {
                outputStream?.write((data + "\n").toByteArray(Charsets.UTF_8))
                outputStream?.flush()
            } catch (e: IOException) {
                Log.e(TAG, "Error writing to $address: ${e.message}")
                cancel()
                onConnectionLost(address)
            }
        }

        fun cancel() {
            try {
                socket.close()
            } catch (e: IOException) {
                Log.e(TAG, "Error closing socket for $address")
            }
        }
    }
}
