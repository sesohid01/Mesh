package com.meshtalk.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey
    val messageId: String,       // UUID for deduplication
    val conversationId: String,  // Contact's deviceId
    val senderId: String,        // Sender's deviceId
    val receiverId: String,      // Receiver's deviceId
    val content: String,         // Message text
    val timestamp: Long,         // Send timestamp (epoch ms)
    val status: MessageStatus,   // Sent, Delivered, etc.
    val isMine: Boolean          // True if sent by this device
)

enum class MessageStatus {
    SENDING,
    SENT,
    DELIVERED,
    FAILED
}
