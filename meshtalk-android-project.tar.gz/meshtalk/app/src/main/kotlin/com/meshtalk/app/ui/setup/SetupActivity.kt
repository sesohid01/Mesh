package com.meshtalk.app.ui.setup

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.meshtalk.app.databinding.ActivitySetupBinding
import com.meshtalk.app.ui.MainActivity
import com.meshtalk.app.utils.DeviceIdentity

class SetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySetupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val deviceId = DeviceIdentity.getDeviceId(this)
        binding.tvDeviceId.text = "Your Device ID: $deviceId"

        binding.btnContinue.setOnClickListener {
            val name = binding.etDisplayName.text?.toString()?.trim()
            if (name.isNullOrBlank() || name.length < 2) {
                Toast.makeText(this, "Please enter a display name (at least 2 characters)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val prefs = getSharedPreferences("meshtalk_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("display_name", name)
                .putBoolean("setup_done", true)
                .apply()

            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
