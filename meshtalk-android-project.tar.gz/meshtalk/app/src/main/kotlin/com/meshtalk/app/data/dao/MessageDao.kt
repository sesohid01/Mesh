package com.meshtalk.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.meshtalk.app.data.entity.Message
import com.meshtalk.app.data.entity.MessageStatus

@Dao
interface MessageDao {

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): LiveData<List<Message>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLastMessage(conversationId: String): Message?

    @Query("SELECT * FROM messages WHERE messageId = :messageId LIMIT 1")
    suspend fun getMessageById(messageId: String): Message?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(message: Message)

    @Query("UPDATE messages SET status = :status WHERE messageId = :messageId")
    suspend fun updateMessageStatus(messageId: String, status: MessageStatus)

    @Query("SELECT DISTINCT conversationId FROM messages ORDER BY (SELECT MAX(timestamp) FROM messages m2 WHERE m2.conversationId = messages.conversationId) DESC")
    fun getConversations(): LiveData<List<String>>

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteConversation(conversationId: String)
}
