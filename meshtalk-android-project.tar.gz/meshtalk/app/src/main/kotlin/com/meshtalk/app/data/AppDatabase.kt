package com.meshtalk.app.data

import android.content.Context
import androidx.room.*
import com.meshtalk.app.data.dao.ContactDao
import com.meshtalk.app.data.dao.MessageDao
import com.meshtalk.app.data.entity.Contact
import com.meshtalk.app.data.entity.Message

@Database(
    entities = [Contact::class, Message::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun contactDao(): ContactDao
    abstract fun messageDao(): MessageDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "meshtalk_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
