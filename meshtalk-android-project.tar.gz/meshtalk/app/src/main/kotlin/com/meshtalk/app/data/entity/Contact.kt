package com.meshtalk.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey
    val deviceId: String,        // Unique device identifier (MAC address or UUID)
    val name: String,            // Display name
    val bluetoothAddress: String, // Last known BT address
    val isSaved: Boolean = false, // Saved contact vs discovered peer
    val lastSeen: Long = 0L,     // Last seen timestamp
    val isOnline: Boolean = false, // Currently reachable via mesh
    val hops: Int = 0,           // Number of hops to reach this contact
    val rssi: Int = 0            // Signal strength (direct connection only)
)
