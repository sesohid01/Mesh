package com.meshtalk.app.ui.call

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.meshtalk.app.databinding.ActivityCallBinding
import com.meshtalk.app.service.CallStateEnum
import com.meshtalk.app.service.MeshNetworkService
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class CallActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_IS_INCOMING = "is_incoming"
        const val EXTRA_CALL_ID = "call_id"
        const val EXTRA_PEER_ID = "peer_id"
        const val EXTRA_PEER_NAME = "peer_name"
    }

    private lateinit var binding: ActivityCallBinding
    private var isIncoming = false
    private var peerId = ""
    private var peerName = ""
    private var callId = ""

    private val callDurationHandler = Handler(Looper.getMainLooper())
    private var callDurationSeconds = 0
    private val callDurationRunnable = object : Runnable {
        override fun run() {
            callDurationSeconds++
            val minutes = callDurationSeconds / 60
            val seconds = callDurationSeconds % 60
            binding.tvCallDuration.text = String.format("%02d:%02d", minutes, seconds)
            callDurationHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show on lock screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        isIncoming = intent.getBooleanExtra(EXTRA_IS_INCOMING, false)
        peerId = intent.getStringExtra(EXTRA_PEER_ID) ?: ""
        peerName = intent.getStringExtra(EXTRA_PEER_NAME) ?: "Unknown"
        callId = intent.getStringExtra(EXTRA_CALL_ID) ?: ""

        binding = ActivityCallBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvPeerName.text = peerName
        binding.tvInitial.text = peerName.firstOrNull()?.uppercase() ?: "?"

        if (isIncoming) {
            showIncomingCallUI()
        } else {
            showOutgoingCallUI()
            initiateCall()
        }

        // Observe call state
        MeshNetworkService.activeCallState.onEach { callState ->
            if (callState == null) {
                finish()
                return@onEach
            }
            when (callState.state) {
                CallStateEnum.ACTIVE -> {
                    showActiveCallUI()
                    if (callDurationSeconds == 0) {
                        callDurationHandler.post(callDurationRunnable)
                    }
                }
                CallStateEnum.CALLING -> {
                    binding.tvCallStatus.text = "Calling..."
                }
                CallStateEnum.ENDED -> finish()
            }
            binding.btnMute.isSelected = callState.isMuted
        }.launchIn(lifecycleScope)

        binding.btnEndCall.setOnClickListener {
            startService(Intent(this, MeshNetworkService::class.java).apply {
                action = MeshNetworkService.ACTION_END_CALL
            })
            finish()
        }

        binding.btnAcceptCall.setOnClickListener {
            startService(Intent(this, MeshNetworkService::class.java).apply {
                action = MeshNetworkService.ACTION_ACCEPT_CALL
            })
        }

        binding.btnRejectCall.setOnClickListener {
            startService(Intent(this, MeshNetworkService::class.java).apply {
                action = MeshNetworkService.ACTION_REJECT_CALL
            })
            finish()
        }

        binding.btnMute.setOnClickListener {
            startService(Intent(this, MeshNetworkService::class.java).apply {
                action = MeshNetworkService.ACTION_TOGGLE_MUTE
            })
        }
    }

    private fun initiateCall() {
        startService(Intent(this, MeshNetworkService::class.java).apply {
            action = MeshNetworkService.ACTION_MAKE_CALL
            putExtra(MeshNetworkService.EXTRA_TARGET_DEVICE_ID, peerId)
        })
    }

    private fun showIncomingCallUI() {
        binding.tvCallStatus.text = "Incoming Call"
        binding.layoutIncomingActions.visibility = android.view.View.VISIBLE
        binding.layoutActiveActions.visibility = android.view.View.GONE
        binding.tvCallDuration.visibility = android.view.View.GONE
    }

    private fun showOutgoingCallUI() {
        binding.tvCallStatus.text = "Calling..."
        binding.layoutIncomingActions.visibility = android.view.View.GONE
        binding.layoutActiveActions.visibility = android.view.View.VISIBLE
        binding.tvCallDuration.visibility = android.view.View.GONE
        binding.btnMute.visibility = android.view.View.GONE
    }

    private fun showActiveCallUI() {
        binding.tvCallStatus.text = "Connected"
        binding.layoutIncomingActions.visibility = android.view.View.GONE
        binding.layoutActiveActions.visibility = android.view.View.VISIBLE
        binding.tvCallDuration.visibility = android.view.View.VISIBLE
        binding.btnMute.visibility = android.view.View.VISIBLE
    }

    override fun onDestroy() {
        super.onDestroy()
        callDurationHandler.removeCallbacks(callDurationRunnable)
    }
}
