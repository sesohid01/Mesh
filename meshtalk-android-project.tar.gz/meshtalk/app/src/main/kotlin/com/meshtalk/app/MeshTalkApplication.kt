package com.meshtalk.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.meshtalk.app.data.AppDatabase

class MeshTalkApplication : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getDatabase(this)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Mesh service channel
            val meshChannel = NotificationChannel(
                CHANNEL_MESH_SERVICE,
                "Mesh Network Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the Bluetooth mesh network running"
            }

            // Message channel
            val messageChannel = NotificationChannel(
                CHANNEL_MESSAGES,
                "Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming messages from contacts"
                enableVibration(true)
            }

            // Call channel
            val callChannel = NotificationChannel(
                CHANNEL_CALLS,
                "Calls",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming voice calls"
                enableVibration(true)
            }

            manager.createNotificationChannels(
                listOf(meshChannel, messageChannel, callChannel)
            )
        }
    }

    companion object {
        lateinit var instance: MeshTalkApplication
            private set

        const val CHANNEL_MESH_SERVICE = "mesh_service"
        const val CHANNEL_MESSAGES = "messages"
        const val CHANNEL_CALLS = "calls"
    }
}
