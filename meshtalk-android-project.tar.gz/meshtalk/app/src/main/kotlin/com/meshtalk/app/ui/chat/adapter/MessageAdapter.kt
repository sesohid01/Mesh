package com.meshtalk.app.ui.chat.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.meshtalk.app.R
import com.meshtalk.app.data.entity.Message
import com.meshtalk.app.data.entity.MessageStatus
import com.meshtalk.app.databinding.ItemMessageMineBinding
import com.meshtalk.app.databinding.ItemMessageTheirsBinding
import java.text.SimpleDateFormat
import java.util.*

class MessageAdapter(
    private val localDeviceId: String
) : ListAdapter<Message, RecyclerView.ViewHolder>(DIFF_CALLBACK) {

    companion object {
        const val VIEW_TYPE_MINE = 1
        const val VIEW_TYPE_THEIRS = 2

        val TIME_FORMAT = SimpleDateFormat("HH:mm", Locale.getDefault())

        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Message>() {
            override fun areItemsTheSame(oldItem: Message, newItem: Message) =
                oldItem.messageId == newItem.messageId
            override fun areContentsTheSame(oldItem: Message, newItem: Message) =
                oldItem == newItem
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (getItem(position).isMine) VIEW_TYPE_MINE else VIEW_TYPE_THEIRS
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_MINE) {
            val binding = ItemMessageMineBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
            MineViewHolder(binding)
        } else {
            val binding = ItemMessageTheirsBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
            TheirsViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = getItem(position)
        when (holder) {
            is MineViewHolder -> holder.bind(message)
            is TheirsViewHolder -> holder.bind(message)
        }
    }

    inner class MineViewHolder(
        private val binding: ItemMessageMineBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(message: Message) {
            binding.tvContent.text = message.content
            binding.tvTime.text = TIME_FORMAT.format(Date(message.timestamp))
            binding.ivStatus.setImageResource(
                when (message.status) {
                    MessageStatus.SENDING -> R.drawable.ic_clock
                    MessageStatus.SENT -> R.drawable.ic_check
                    MessageStatus.DELIVERED -> R.drawable.ic_check_double
                    MessageStatus.FAILED -> R.drawable.ic_error
                }
            )
        }
    }

    inner class TheirsViewHolder(
        private val binding: ItemMessageTheirsBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(message: Message) {
            binding.tvContent.text = message.content
            binding.tvTime.text = TIME_FORMAT.format(Date(message.timestamp))
        }
    }
}
