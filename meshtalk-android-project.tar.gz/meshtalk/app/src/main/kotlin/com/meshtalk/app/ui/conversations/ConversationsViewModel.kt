package com.meshtalk.app.ui.conversations

import androidx.lifecycle.*
import com.meshtalk.app.data.dao.ContactDao
import com.meshtalk.app.data.dao.MessageDao
import com.meshtalk.app.data.entity.Contact
import com.meshtalk.app.data.entity.Message
import kotlinx.coroutines.launch

data class ConversationItem(
    val contactId: String,
    val contactName: String,
    val lastMessage: String,
    val lastMessageTime: Long,
    val isOnline: Boolean
)

class ConversationsViewModel(
    private val messageDao: MessageDao,
    private val contactDao: ContactDao
) : ViewModel() {

    val conversations: LiveData<List<ConversationItem>> =
        contactDao.getAllContacts().switchMap { contacts ->
            liveData {
                val items = contacts.mapNotNull { contact ->
                    val lastMsg = messageDao.getLastMessage(contact.deviceId)
                    lastMsg?.let {
                        ConversationItem(
                            contactId = contact.deviceId,
                            contactName = contact.name,
                            lastMessage = it.content,
                            lastMessageTime = it.timestamp,
                            isOnline = contact.isOnline
                        )
                    }
                }.sortedByDescending { it.lastMessageTime }
                emit(items)
            }
        }
}

class ConversationsViewModelFactory(
    private val messageDao: MessageDao,
    private val contactDao: ContactDao
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ConversationsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ConversationsViewModel(messageDao, contactDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
