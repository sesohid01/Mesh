package com.meshtalk.app.audio

import android.content.Context
import android.media.*
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * AudioEngine - handles real-time audio capture and playback for voice calls.
 *
 * - Captures microphone audio and encodes it to bytes
 * - Plays back received audio frames
 * - Uses low-latency settings optimized for Bluetooth transmission
 */
class AudioEngine(private val context: Context) {
    private val TAG = "AudioEngine"

    companion object {
        const val SAMPLE_RATE = 8000       // 8 kHz for narrow-band voice (lower bandwidth)
        const val CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO
        const val CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO
        const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
        const val FRAME_SIZE = 320         // 20ms frames at 8kHz (320 samples)
    }

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var captureJob: Job? = null
    private var isMuted = false

    private val playbackQueue = ConcurrentLinkedQueue<ByteArray>()
    private var playbackJob: Job? = null

    var onAudioFrame: ((ByteArray, Int) -> Unit)? = null  // (audioData, frameIndex)
    private var frameIndex = 0

    /**
     * Start audio capture (microphone → frames → callback).
     */
    fun startCapture(scope: CoroutineScope) {
        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, ENCODING)
        val bufferSize = maxOf(minBufferSize, FRAME_SIZE * 2)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            SAMPLE_RATE,
            CHANNEL_IN,
            ENCODING,
            bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord failed to initialize")
            return
        }

        audioRecord?.startRecording()
        frameIndex = 0

        captureJob = scope.launch(Dispatchers.IO) {
            val buffer = ByteArray(FRAME_SIZE * 2)  // 2 bytes per sample (PCM_16BIT)
            Log.i(TAG, "Audio capture started")

            while (isActive) {
                val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: break
                if (bytesRead > 0 && !isMuted) {
                    val frame = buffer.copyOf(bytesRead)
                    onAudioFrame?.invoke(frame, frameIndex++)
                }
            }
        }
    }

    /**
     * Start audio playback (received frames → speaker).
     */
    fun startPlayback(scope: CoroutineScope) {
        val minBufferSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_OUT, ENCODING)
        val bufferSize = maxOf(minBufferSize, FRAME_SIZE * 4)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(ENCODING)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(CHANNEL_OUT)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()
        Log.i(TAG, "Audio playback started")

        playbackJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                val frame = playbackQueue.poll()
                if (frame != null) {
                    audioTrack?.write(frame, 0, frame.size)
                } else {
                    delay(5)  // Wait briefly before polling again
                }
            }
        }
    }

    /**
     * Queue an audio frame for playback.
     * @param base64Data Base64-encoded PCM audio data
     */
    fun queueAudioFrame(base64Data: String) {
        try {
            val audioBytes = Base64.decode(base64Data, Base64.DEFAULT)
            playbackQueue.offer(audioBytes)
        } catch (e: Exception) {
            Log.e(TAG, "Error decoding audio frame: ${e.message}")
        }
    }

    /**
     * Encode raw audio bytes to Base64 for transmission.
     */
    fun encodeAudioFrame(audioData: ByteArray): String {
        return Base64.encodeToString(audioData, Base64.DEFAULT)
    }

    fun setMuted(muted: Boolean) {
        isMuted = muted
        Log.d(TAG, "Muted: $muted")
    }

    fun isMuted(): Boolean = isMuted

    /**
     * Set audio to use speakerphone or earpiece.
     */
    fun setSpeakerMode(useSpeaker: Boolean) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.isSpeakerphoneOn = useSpeaker
        Log.d(TAG, "Speaker mode: $useSpeaker")
    }

    /**
     * Set audio mode for active call.
     */
    fun setCallAudioMode() {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = false
    }

    /**
     * Restore normal audio mode after call.
     */
    fun restoreAudioMode() {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_NORMAL
        audioManager.isSpeakerphoneOn = false
    }

    fun stop() {
        captureJob?.cancel()
        playbackJob?.cancel()
        captureJob = null
        playbackJob = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping AudioRecord: ${e.message}")
        }

        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping AudioTrack: ${e.message}")
        }

        playbackQueue.clear()
        Log.i(TAG, "Audio engine stopped")
    }
}
