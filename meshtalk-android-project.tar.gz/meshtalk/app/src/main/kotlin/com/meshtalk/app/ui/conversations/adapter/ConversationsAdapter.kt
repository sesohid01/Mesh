package com.meshtalk.app.ui.conversations.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.meshtalk.app.databinding.ItemConversationBinding
import com.meshtalk.app.ui.conversations.ConversationItem
import java.text.SimpleDateFormat
import java.util.*

class ConversationsAdapter(
    private val onConversationClicked: (contactId: String, contactName: String) -> Unit
) : ListAdapter<ConversationItem, ConversationsAdapter.ConversationViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConversationViewHolder {
        val binding = ItemConversationBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ConversationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ConversationViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ConversationViewHolder(
        private val binding: ItemConversationBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ConversationItem) {
            binding.tvName.text = item.contactName
            binding.tvLastMessage.text = item.lastMessage
            binding.tvInitial.text = item.contactName.firstOrNull()?.uppercase() ?: "?"

            val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
            binding.tvTime.text = timeFormat.format(Date(item.lastMessageTime))

            binding.ivOnline.visibility = if (item.isOnline)
                android.view.View.VISIBLE else android.view.View.INVISIBLE

            binding.root.setOnClickListener {
                onConversationClicked(item.contactId, item.contactName)
            }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ConversationItem>() {
            override fun areItemsTheSame(old: ConversationItem, new: ConversationItem) =
                old.contactId == new.contactId
            override fun areContentsTheSame(old: ConversationItem, new: ConversationItem) =
                old == new
        }
    }
}
