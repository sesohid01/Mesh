package com.meshtalk.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.meshtalk.app.data.entity.Contact

@Dao
interface ContactDao {

    @Query("SELECT * FROM contacts ORDER BY isSaved DESC, lastSeen DESC")
    fun getAllContacts(): LiveData<List<Contact>>

    @Query("SELECT * FROM contacts WHERE isSaved = 1 ORDER BY name ASC")
    fun getSavedContacts(): LiveData<List<Contact>>

    @Query("SELECT * FROM contacts WHERE isOnline = 1 ORDER BY hops ASC, rssi DESC")
    fun getNearbyContacts(): LiveData<List<Contact>>

    @Query("SELECT * FROM contacts WHERE deviceId = :deviceId LIMIT 1")
    suspend fun getContactById(deviceId: String): Contact?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: Contact)

    @Update
    suspend fun updateContact(contact: Contact)

    @Query("UPDATE contacts SET isOnline = :isOnline, hops = :hops, lastSeen = :lastSeen WHERE deviceId = :deviceId")
    suspend fun updateOnlineStatus(deviceId: String, isOnline: Boolean, hops: Int, lastSeen: Long)

    @Query("UPDATE contacts SET isOnline = 0 WHERE deviceId NOT IN (:activeIds)")
    suspend fun setOfflineExcept(activeIds: List<String>)

    @Query("UPDATE contacts SET isOnline = 0")
    suspend fun setAllOffline()

    @Query("UPDATE contacts SET isSaved = 1, name = :name WHERE deviceId = :deviceId")
    suspend fun saveContact(deviceId: String, name: String)

    @Delete
    suspend fun deleteContact(contact: Contact)
}
