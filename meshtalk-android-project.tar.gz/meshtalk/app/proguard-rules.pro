-keepattributes Signature
-keepattributes *Annotation*

# Keep data classes for Room
-keep class com.meshtalk.app.data.entity.** { *; }

# Keep mesh packet classes for Gson
-keep class com.meshtalk.app.mesh.** { *; }

# Keep Gson
-keepnames class com.google.gson.** { *; }
-keep class com.google.gson.stream.** { *; }
